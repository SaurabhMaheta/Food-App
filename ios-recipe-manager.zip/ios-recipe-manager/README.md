# Recipes
Simple iOS App that manages all your recipes.

## General
Author: Tonnanto  
This project is currently on pause and not available on the AppStore yet.
Development might continue in the near future.

## Features
- Find all your favourite recipes in one app.
- Create your own detailed recipes that can't be found on any other app.
- Add recipes to recipe books and share them with your friends and family via iCloud.
